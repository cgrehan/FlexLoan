<?php

namespace App\Console;

use Laravel\Lumen\Console\Kernel as ConsoleKernel;

/**
 * Class Kernel.
 */
class Kernel extends ConsoleKernel
{
    /**
     * Commands should be loaded.
     * @var array
     */
    protected $commands = [];
}
