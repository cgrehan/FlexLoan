<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * Class User.
 */
class User extends Model
{
}
